Contents

Source Files - drivespeed.c, cpuidc.c, cpuidh.h
Benchmark    - DriveSpeed
Example log  - driveSpeed.txt

Run time parameters  - ./DriveSpeed
                     - ./DriveSpeed MBytes xx, FilePath /dddd/dddd
                 or  - ./DriveSpeed M xx, F /dddd/dddd


See http://www.roylongbottom.org.uk/Raspberry%20Pi%20Benchmarks.htm
for details on how to use attcached devices and for results.
