Compile commands are in each C file, where options setting should be changed to indicate use of a different compiler or options.

Note lloops2.c is required to compile and run using gcc 4.8 (or later?)

